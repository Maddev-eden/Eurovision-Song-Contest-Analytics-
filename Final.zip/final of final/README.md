# Eurovision Data Analytics Dashboard (1956 – 2026)

This project is an interactive web-based data visualization platform that explores the rich history, geopolitical dynamics, and patterns of the Eurovision Song Contest from its inception in 1956 up to 2026. Built using **D3.js**, it provides a deep dive into historical dominance, qualification patterns, voting alliances, and country trajectories.

---

## 🇩🇪 Deutsch

### Projektbeschreibung
Dieses Dashboard wurde entwickelt, um die historischen und geopolitischen Muster des Eurovision Song Contests (1956–2026) verständlich zu machen. Das Projekt ist in vier analytische Hauptaspekte unterteilt:
1. **Historische Dominanz (*Wer dominiert historisch?*):** Eine geografische Karte zur Analyse von Gewinnhäufigkeiten, durchschnittlichen Platzierungen und dem berechneten "Prestige Score".
2. **Qualifikationsmuster (*Matrix & Finalplatzierungsmuster*):** Eine detaillierte Heatmap zur Analyse des Einflusses von Halbfinalrunden und historischen Qualifikationssträhnen.
3. **Allianz-Cluster (*Knoten-Kanten & Stimmblöcke*):** Eine netzwerkbasierte Cluster-Visualisierung (Force-Directed Graph), die kulturelle, sprachliche und geopolitische Abstimmungsbündnisse offenlegt.
4. **Länderperspektive (*Wie entwickelt sich ein Land über die Zeit?*):** Ein interaktives Liniendiagramm zur Nachverfolgung von goldenen Ären, Krisen und Comebacks einzelner Nationen im historischen Verlauf.

### Wichtiger Hinweis zum Starten des Projekts
Aufgrund von Sicherheitsbeschränkungen moderner Browser (CORS-Richtlinien beim Laden von lokalen JSON-Dateien wie `europeUltra.json`, `entries.json` und `votes_final.json`) **kann das Projekt nicht direkt durch Doppelklick auf die HTML-Dateien geöffnet werden**.

**Voraussetzungen & Start:**
1. Öffnen Sie den gesamten Projektordner in **Visual Studio Code (VS Code)**.
2. Stellen Sie sicher, dass die Extension **Live Server** (von Ritwick Dey) installiert ist.
3. Öffnen Sie die Datei **`index.html`** im Editor.
4. Klicken Sie unten rechts in der Statusleiste auf **"Go Live"** oder machen Sie einen Rechtsklick auf `index.html` und wählen Sie **"Open with Live Server"**.
5. Ihr Browser öffnet automatisch das Dashboard unter einer lokalen Adresse (z. B. `http://127.0.0.1:5500/index.html`).

---

## 🇬🇧 English

### Project Description
This interactive dashboard analyzes the historical and geopolitical dynamics of the Eurovision Song Contest (1956–2026). The analytics platform is structured into four core aspects:
1. **Historical Dominance:** A geospatial visualization examining victory frequencies, average ranks, and custom "Prestige Scores" across competing nations.
2. **Qualification Patterns (Matrix & Heatmap):** A comprehensive temporal heatmap illustrating the structural impact of semi-finals and historic qualification streaks.
3. **Alliance Clusters (Nodes & Edges):** A dynamic force-directed network graph exposing cultural, linguistic, and regional voting blocs (e.g., Nordic, Balkan, and Baltic clusters).
4. **Country Trajectories:** An interactive time-series line chart tracking the rise, fall, golden eras, and comebacks of individual countries across the decades.

### Crucial Setup Instruction
Due to browser security restrictions regarding local file loading (CORS policies applied to asynchronous fetching of `europeUltra.json`, `entries.json`, and `votes_final.json`), **the project will fail to load data if opened directly via a double-click on the HTML files**.

**How to Launch:**
1. Open the root folder of the project in **Visual Studio Code (VS Code)**.
2. Ensure you have the **Live Server** extension (by Ritwick Dey) installed.
3. Navigate to and open the **`index.html`** file.
4. Click on **"Go Live"** in the bottom-right status bar of VS Code, or right-click `index.html` and select **"Open with Live Server"**.
5. The application will launch seamlessly in your default web browser (typically at `http://127.0.0.1:5500/index.html`).

---

### Tech Stack
* **Frontend Logic & Visualization:** HTML5, CSS3 (Poppins typography), JavaScript (ES6+)
* **Core Libraries:** [D3.js (Data-Driven Documents)](https://d3js.org/), FontAwesome Icons
* **Data Sources:** `entries.json` (historical performances), `votes_final.json` (voting matrix), `europeUltra.json` (geographic boundary coordinates)
